const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Propriedades do Jogador
const player = {
  x: canvas.width / 2,
  y: canvas.height - 50,
  width: 50,
  height: 50,
  speed: 5,
  bullets: [],
  cooldown: 0
};

// Propriedades dos Inimigos
const enemies = [];
const enemySpeed = 2;
const spawnInterval = 100;
let frames = 0;

// Controlar teclas pressionadas
const keys = {};

window.addEventListener('keydown', (e) => {
  keys[e.key] = true;
});

window.addEventListener('keyup', (e) => {
  keys[e.key] = false;
});

function shoot() {
  if (player.cooldown === 0) {
    player.bullets.push({
      x: player.x + player.width / 2 - 2.5,
      y: player.y,
      width: 5,
      height: 10,
      speed: 7
    });
    player.cooldown = 20;
  }
}

function updateBullets() {
  player.bullets.forEach((bullet, index) => {
    bullet.y -= bullet.speed;
    if (bullet.y < 0) {
      player.bullets.splice(index, 1);
    }
  });
}

function spawnEnemies() {
  if (frames % spawnInterval === 0) {
    enemies.push({
      x: Math.random() * (canvas.width - 50),
      y: -50,
      width: 50,
      height: 50
    });
  }
}

function updateEnemies() {
  enemies.forEach((enemy, index) => {
    enemy.y += enemySpeed;
    if (enemy.y > canvas.height) {
      enemies.splice(index, 1);
    }
  });
}

function checkCollisions() {
  player.bullets.forEach((bullet, bulletIndex) => {
    enemies.forEach((enemy, enemyIndex) => {
      if (
        bullet.x < enemy.x + enemy.width &&
        bullet.x + bullet.width > enemy.x &&
        bullet.y < enemy.y + enemy.height &&
        bullet.y + bullet.height > enemy.y
      ) {
        enemies.splice(enemyIndex, 1);
        player.bullets.splice(bulletIndex, 1);
      }
    });
  });
}

function update() {
  // Movimentação do jogador
  if (keys['ArrowRight'] && player.x + player.width < canvas.width) {
    player.x += player.speed;
  }
  if (keys['ArrowLeft'] && player.x > 0) {
    player.x -= player.speed;
  }
  if (keys[' ']) {
    shoot();
  }

  // Atualizar cooldown do tiro
  if (player.cooldown > 0) {
    player.cooldown--;
  }

  updateBullets();
  spawnEnemies();
  updateEnemies();
  checkCollisions();
}

function drawPlayer() {
  ctx.fillStyle = 'blue';
  ctx.fillRect(player.x, player.y, player.width, player.height);
}

function drawBullets() {
  ctx.fillStyle = 'red';
  player.bullets.forEach(bullet => {
    ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
  });
}

function drawEnemies() {
  ctx.fillStyle = 'green';
  enemies.forEach(enemy => {
    ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
  });
}

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  drawPlayer();
  drawBullets();
  drawEnemies();
  update();
  
  frames++;
  requestAnimationFrame(gameLoop);
}

gameLoop();
